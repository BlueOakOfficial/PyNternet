f=open('welcome.txt','r')
f.readline()
print()
f.close